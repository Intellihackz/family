"use strict";
(() => {
  // src/config.mjs
  var API = "https://family-production-e140.up.railway.app";

  // src/background.ts
  async function call(path, init) {
    const r = await fetch(`${API}${path}`, init);
    const j = await r.json();
    if (!r.ok) throw new Error(j.error ?? `http_${r.status}`);
    return j;
  }
  function run(m) {
    switch (m.type) {
      case "holder":
        return call(`/holder?token=${m.token}&address=${m.address}`);
      case "holders":
        return call(`/holders?token=${m.token}`);
      case "poll":
        return call(`/rooms/${m.token}/messages?address=${m.address}&after=${m.after}`);
      case "send":
        return call(`/rooms/${m.token}/messages`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ address: m.address, text: m.text }) });
    }
  }
  chrome.runtime.onMessage.addListener((m, _sender, send) => {
    run(m).then((data) => send({ ok: true, data }), (e) => send({ ok: false, error: String(e?.message ?? e) }));
    return true;
  });
})();
//# sourceMappingURL=background.js.map
