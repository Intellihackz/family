"use strict";
(() => {
  // src/core/siteWallet.ts
  function mapEntries(v) {
    if (v?.__type === "Map") return v.value;
    return Object.entries(v ?? {});
  }
  function readSiteWallet() {
    try {
      const raw = localStorage.getItem("wagmi.store");
      if (!raw) return null;
      const state = JSON.parse(raw)?.state;
      const conns = mapEntries(state?.connections);
      const cur = conns.find(([uid]) => uid === state?.current)?.[1] ?? conns[0]?.[1];
      const address = cur?.accounts?.[0];
      if (!address) return null;
      return {
        address: String(address).toLowerCase(),
        chainId: Number(cur.chainId ?? state?.chainId),
        connectorId: cur.connector?.id ?? "",
        connectorName: cur.connector?.name ?? "wallet",
        connectorType: cur.connector?.type ?? ""
      };
    } catch {
      return null;
    }
  }
  function watchSiteWallet(cb, ms = 1500) {
    let last = "__init__";
    const tick = () => {
      const w = readSiteWallet();
      const key = w ? `${w.address}:${w.chainId}:${w.connectorId}` : "";
      if (key !== last) {
        last = key;
        cb(w);
      }
    };
    tick();
    const id = setInterval(tick, ms);
    return () => clearInterval(id);
  }

  // src/core/room.ts
  async function bg(m) {
    const r = await chrome.runtime.sendMessage(m);
    if (!r?.ok) throw new Error(r?.error ?? "background_failed");
    return r.data;
  }
  var checkHolder = (token2, address) => bg({ type: "holder", token: token2, address });
  var holderCount = (token2) => bg({ type: "holders", token: token2 }).then((r) => r.count);
  var pollMessages = (token2, address, after) => bg({ type: "poll", token: token2, address, after });
  var sendMessage = (token2, address, text) => bg({ type: "send", token: token2, address, text });

  // src/core/token.ts
  var TOKEN_PATH = /^\/launchpad\/(0x[a-fA-F0-9]{40})\/?$/;
  function tokenFromLocation(loc = window.location) {
    const m = loc.pathname.match(TOKEN_PATH);
    return m ? m[1].toLowerCase() : null;
  }

  // src/theme.ts
  var light = {
    bg: "#ffffff",
    surface: "#f5f5f7",
    raised: "#eceee9",
    border: "rgba(12, 21, 0, 0.14)",
    text: "#0c1500",
    muted: "rgba(12, 21, 0, 0.62)",
    accent: "#00c805",
    // fills, dots, buttons
    accentText: "#008a06",
    // accent used as text on white (the fill green is too light to read)
    onAccent: "#0c1500",
    // text on an accent fill, as on the site's Buy button
    warn: "#e04600",
    shadow: "0 2px 4px rgba(12, 21, 0, 0.08), 0 12px 32px rgba(12, 21, 0, 0.11)",
    nameL: "36%"
  };
  var dark = {
    bg: "#1c1c1c",
    surface: "#252525",
    raised: "#2e2e2e",
    border: "rgba(253, 254, 249, 0.12)",
    text: "#fdfef9",
    muted: "rgba(253, 254, 249, 0.62)",
    accent: "#00c805",
    accentText: "#00c805",
    onAccent: "#0c1500",
    warn: "#ff5000",
    shadow: "0 2px 4px rgba(0, 0, 0, 0.34), 0 12px 32px rgba(0, 0, 0, 0.32)",
    nameL: "68%"
  };
  var theme = {
    wordmark: "family",
    hostTag: "on pons",
    footer: "community built, not affiliated with pons",
    font: `ui-rounded, "SF Pro Rounded", Nunito, system-ui, -apple-system, "Segoe UI", sans-serif`,
    radius: "24px",
    palettes: { light, dark }
  };
  var cssVars = (p) => `--bg:${p.bg};--surface:${p.surface};--raised:${p.raised};--border:${p.border};--text:${p.text};--muted:${p.muted};--accent:${p.accent};--accent-text:${p.accentText};--on-accent:${p.onAccent};--warn:${p.warn};--shadow:${p.shadow};--name-l:${p.nameL};`;

  // src/core/siteTheme.ts
  function readSiteTheme() {
    const attr = document.documentElement.dataset.pTheme;
    if (attr === "dark" || attr === "light") return attr;
    const rgb = getComputedStyle(document.body ?? document.documentElement).backgroundColor.match(/[\d.]+/g)?.map(Number);
    if (rgb && rgb.length >= 3 && (rgb.length < 4 || rgb[3] > 0)) {
      const [r, g, b] = rgb;
      return 0.299 * r + 0.587 * g + 0.114 * b < 128 ? "dark" : "light";
    }
    return matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  function watchSiteTheme(cb) {
    let last;
    const tick = () => {
      const m = readSiteTheme();
      if (m !== last) {
        last = m;
        cb(m);
      }
    };
    tick();
    new MutationObserver(tick).observe(document.documentElement, { attributes: true });
    if (document.body) new MutationObserver(tick).observe(document.body, { attributes: true });
  }

  // assets/mark.svg
  var mark_default = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" width="128" height="128">
  <title>family</title>
  <defs>
    <!-- one continuous F silhouette: chunky bars, fully rounded ends, softened inner corners -->
    <path id="f" d="M45 14H83A17 17 0 0 1 83 48H69A5 5 0 0 0 64 53A5 5 0 0 0 69 58H73A15 15 0 0 1 73 88H69A5 5 0 0 0 64 93V96A18 18 0 0 1 28 96V31A17 17 0 0 1 45 14Z"/>
    <clipPath id="clip"><use href="#f"/></clipPath>
    <linearGradient id="body" gradientUnits="userSpaceOnUse" x1="0" y1="14" x2="0" y2="114">
      <stop offset="0" stop-color="#dde3df"/><stop offset=".5" stop-color="#a9b4ac"/><stop offset="1" stop-color="#7a877f"/>
    </linearGradient>
    <linearGradient id="rim" gradientUnits="userSpaceOnUse" x1="28" y1="14" x2="100" y2="114">
      <stop offset="0" stop-color="#8fcfa4"/><stop offset=".5" stop-color="#4e9a6a"/><stop offset="1" stop-color="#2a6544"/>
    </linearGradient>
    <linearGradient id="gloss" gradientUnits="userSpaceOnUse" x1="0" y1="16" x2="0" y2="46">
      <stop offset="0" stop-color="#fff" stop-opacity=".75"/><stop offset="1" stop-color="#fff" stop-opacity="0"/>
    </linearGradient>
    <linearGradient id="glow" gradientUnits="userSpaceOnUse" x1="0" y1="70" x2="0" y2="114">
      <stop offset="0" stop-color="#00c805" stop-opacity="0"/><stop offset="1" stop-color="#00c805" stop-opacity=".28"/>
    </linearGradient>
  </defs>

  <!-- green rim: the silhouette stroked, so only its outer half shows once the body is on top -->
  <use href="#f" fill="url(#rim)" stroke="url(#rim)" stroke-width="5" stroke-linejoin="round"/>
  <!-- glass body -->
  <use href="#f" fill="url(#body)"/>
  <g clip-path="url(#clip)">
    <rect x="28" y="70" width="80" height="48" fill="url(#glow)"/>
    <rect x="28" y="14" width="80" height="34" fill="url(#gloss)"/>
    <!-- thin bright lip just inside the rim, like the reference's glass edge -->
    <use href="#f" fill="none" stroke="#fff" stroke-opacity=".6" stroke-width="1.6"/>
  </g>
</svg>
`;

  // src/core/chain.ts
  var CHAIN = {
    id: 4663,
    name: "Robinhood Chain",
    explorer: "https://robinhoodchain.blockscout.com"
    // TODO: RPC url is not confirmed yet. Server side only, never hardcode a guess.
  };
  var isRobinhood = (chainId) => chainId === CHAIN.id;

  // src/shell/panel.ts
  var svg = (d, size = 16, sw = 1.6) => `<svg viewBox="0 0 16 16" width="${size}" height="${size}" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
  var ICON = {
    min: svg(`<path d="M3.5 8h9"/>`),
    send: svg(`<path d="M3 8h9.5M8.5 4l4 4-4 4"/>`),
    lock: svg(`<rect x="3.5" y="7" width="9" height="6.5" rx="1.8"/><path d="M5.5 7V5.2a2.5 2.5 0 0 1 5 0V7"/>`, 22, 1.4)
  };
  var esc = (s) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  var short = (a) => `${a.slice(0, 6)}\u2026${a.slice(-4)}`;
  var hue = (a) => {
    let h = 0;
    for (const c of a.toLowerCase()) h = (h * 31 + c.charCodeAt(0)) % 360;
    return h;
  };
  var fmtPct = (p) => `${p.toFixed(p < 1 ? 3 : 1)}%`;
  var MIN_KEY = "family:minimized";
  var logo = (p) => mark_default.replace('viewBox="0 0 128 128"', 'viewBox="9 9 110 110"').replace(/<title>[\s\S]*?<\/title>/, "").replace(/(id="|url\(#|href="#)(f|clip|body|rim|gloss|glow)(?=["\)])/g, `$1${p}-$2`);
  var CSS = `
  :host{all:initial}
  *{box-sizing:border-box}
  .dock{${cssVars(theme.palettes.light)}
    font:13px/1.45 ${theme.font};color:var(--text);-webkit-font-smoothing:antialiased}
  .dock[data-theme=dark]{${cssVars(theme.palettes.dark)}}
  button{all:unset;box-sizing:border-box;cursor:pointer}
  button:focus-visible,input:focus-visible{outline:2px solid var(--accent);outline-offset:2px}

  .dot{width:8px;height:8px;border-radius:50%;background:var(--muted);flex:none;transition:background .2s,box-shadow .2s}
  .dock[data-s=live] .dot{background:var(--accent);box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 22%,transparent)}
  .dock[data-s=warn] .dot{background:var(--warn)}

  /* minimized: the logo itself is the floating button */
  .logo{position:relative;display:inline-block;flex:none;width:30px;height:30px}
  .logo svg{display:block;width:100%;height:100%}
  .logo .dot{position:absolute;right:-4px;bottom:-3px;width:11px;height:11px;border:2px solid var(--bg)}
  .logo.sm{width:24px;height:24px}
  .logo.sm .dot{width:9px;height:9px;right:-3px;bottom:-2px;border-color:var(--surface)}
  .pill{display:none;position:relative;width:56px;height:56px;border-radius:50%;background:var(--bg);border:1px solid var(--border);
    box-shadow:var(--shadow);place-items:center;transition:border-color .15s,transform .15s}
  .pill:hover{border-color:color-mix(in srgb,var(--accent) 55%,var(--border));transform:translateY(-1px)}
  .unread{position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:var(--accent);color:var(--on-accent);font-size:11px;font-weight:700;display:grid;place-items:center}
  .unread[hidden]{display:none}
  .dock[data-min=true] .pill{display:grid}
  .dock[data-min=true] .card{display:none}

  /* card */
  .card{width:330px;max-height:calc(100vh - 32px);display:flex;flex-direction:column;background:var(--bg);border:1px solid var(--border);
    border-radius:${theme.radius};overflow:hidden;box-shadow:var(--shadow);transform-origin:bottom right;animation:in .18s ease-out}
  @keyframes in{from{opacity:0;transform:translateY(6px) scale(.98)}}
  @media (prefers-reduced-motion:reduce){.card{animation:none}.pill,.dot{transition:none}}

  header{display:flex;align-items:center;gap:8px;padding:11px 12px 11px 14px;border-bottom:1px solid var(--border);background:var(--surface)}
  .mark{font-weight:700;font-size:15px;letter-spacing:-.02em}
  .tag{font-size:11px;color:var(--muted);padding-left:8px;border-left:1px solid var(--border)}
  .icon{margin-left:auto;width:26px;height:26px;border-radius:8px;display:grid;place-items:center;color:var(--muted);transition:background .15s,color .15s}
  .icon:hover{background:var(--raised);color:var(--text)}

  main{padding:14px;display:flex;flex-direction:column;min-height:0}
  footer{padding:8px 14px;font-size:10.5px;color:var(--muted);border-top:1px solid var(--border)}
  .m{color:var(--muted)} .sm{font-size:12px}
  code{font:12px ui-monospace,SFMono-Regular,Menlo,monospace}

  /* gate states */
  .gate{display:flex;flex-direction:column;align-items:flex-start;gap:6px;padding:4px 0 2px}
  .lock{width:44px;height:44px;border-radius:12px;display:grid;place-items:center;background:var(--raised);border:1px solid var(--border);color:var(--accent-text);margin-bottom:6px}
  .gate h3{margin:0;font-size:15px;font-weight:700;letter-spacing:-.01em}
  .stat{margin-top:8px;display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:999px;background:var(--surface);border:1px solid var(--border);font-size:12px}
  .stat b{font-variant-numeric:tabular-nums}
  .note{margin-top:6px;font-size:12px;color:var(--warn)}
  .skel{height:10px;border-radius:5px;background:linear-gradient(90deg,var(--surface),var(--raised),var(--surface));background-size:200% 100%;animation:sh 1.2s linear infinite}
  @keyframes sh{to{background-position:-200% 0}}

  /* holder / chat */
  .bar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:10px}
  .chip{display:inline-flex;align-items:center;gap:6px;padding:3px 9px 3px 7px;border-radius:999px;background:var(--surface);border:1px solid var(--border);font-size:11.5px}
  .chip i{width:8px;height:8px;border-radius:50%}
  .badge{padding:3px 9px;border-radius:999px;font-size:11.5px;font-weight:600;color:var(--accent-text);background:color-mix(in srgb,var(--accent) 14%,transparent);border:1px solid color-mix(in srgb,var(--accent) 40%,transparent)}
  .log{height:min(230px,34vh);overflow-y:auto;display:flex;flex-direction:column;gap:2px;margin:0 -6px;padding:0 6px;scrollbar-width:thin;scrollbar-color:var(--border) transparent}
  .empty{margin:auto;text-align:center;font-size:12px;color:var(--muted)}
  .msg{padding:6px 8px;border-radius:10px}
  .msg.me{background:color-mix(in srgb,var(--accent) 11%,transparent)}
  .meta{display:flex;align-items:baseline;gap:6px;font-size:11px;color:var(--muted)}
  .who{font-weight:600}
  .devtag{padding:0 7px;border-radius:999px;background:var(--accent);color:var(--on-accent);font-size:10px;font-weight:800;line-height:15px;letter-spacing:.02em}
  .time{margin-left:auto;font-variant-numeric:tabular-nums}
  .body{overflow-wrap:anywhere;white-space:pre-wrap}
  form{display:flex;gap:6px;margin-top:10px}
  input{flex:1;min-width:0;background:var(--surface);color:var(--text);border:1px solid var(--border);border-radius:999px;padding:8px 14px;font:inherit;outline:none;transition:border-color .15s}
  input::placeholder{color:var(--muted)}
  input:focus{border-color:var(--accent)}
  .send{width:36px;height:36px;flex:none;border-radius:50%;display:grid;place-items:center;background:var(--accent);color:var(--on-accent);transition:filter .15s,transform .1s}
  .send:hover{filter:brightness(1.08)} .send:active{transform:scale(.95)}
  .notice{min-height:16px;font-size:11px;color:var(--warn);margin-top:6px}
`;
  function mountPanel(onSend) {
    const host = document.createElement("div");
    host.style.cssText = "all:initial;position:fixed;right:16px;bottom:16px;z-index:2147483647";
    const root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
    <style>${CSS}</style>
    <div class="dock" id="dock" data-min="false" data-s="idle">
      <button class="pill" id="pill" aria-label="Open family chat"><span class="logo">${logo("p")}<span class="dot"></span></span><span class="unread" id="unread" hidden></span></button>
      <section class="card" aria-label="${theme.wordmark} chat">
        <header><span class="logo sm">${logo("h")}<span class="dot"></span></span><span class="mark">${theme.wordmark}</span><span class="tag">${theme.hostTag}</span>
          <button class="icon" id="min" aria-label="Minimize" title="Minimize (Esc)">${ICON.min}</button></header>
        <main id="body"></main>
        <footer>${theme.footer}</footer>
      </section>
    </div>`;
    document.documentElement.appendChild(host);
    const place = () => {
      host.style.bottom = window.innerWidth < 900 ? "88px" : "16px";
    };
    place();
    window.addEventListener("resize", place);
    const $ = (id) => root.getElementById(id);
    const dock = $("dock"), body = $("body"), unreadEl = $("unread");
    watchSiteTheme((m) => {
      dock.dataset.theme = m;
    });
    let me = "";
    let unread = 0;
    const getMin = () => {
      try {
        return localStorage.getItem(MIN_KEY) !== "0";
      } catch {
        return true;
      }
    };
    function setMin(v) {
      dock.dataset.min = String(v);
      try {
        localStorage.setItem(MIN_KEY, v ? "1" : "0");
      } catch {
      }
      if (!v) {
        unread = 0;
        showUnread();
        root.getElementById("i")?.focus();
      }
    }
    function showUnread() {
      unreadEl.hidden = unread === 0;
      unreadEl.textContent = unread > 99 ? "99+" : String(unread);
      $("pill").setAttribute("aria-label", unread ? `Open family chat, ${unread} unread` : "Open family chat");
    }
    $("min").addEventListener("click", () => setMin(true));
    $("pill").addEventListener("click", () => setMin(false));
    root.addEventListener("keydown", (e) => {
      if (e.key === "Escape") setMin(true);
    });
    setMin(getMin());
    const NOTICES = {
      slow_down: "Slow down a little.",
      too_long: "Too long, keep it under 280.",
      not_holder: "Hold this token to keep chatting."
    };
    const setNotice = (text) => {
      const n = root.getElementById("n");
      if (n) n.textContent = text;
    };
    function row(m) {
      const mine = m.address === me;
      const el = document.createElement("div");
      el.className = "msg" + (mine ? " me" : "");
      const meta = document.createElement("div");
      meta.className = "meta";
      const who = document.createElement("span");
      who.className = "who";
      who.style.color = `hsl(${hue(m.address)} 55% var(--name-l))`;
      who.textContent = mine ? "you" : short(m.address);
      const pct = document.createElement("span");
      pct.textContent = fmtPct(m.pct);
      const time = document.createElement("span");
      time.className = "time";
      time.textContent = new Date(m.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      meta.append(who);
      if (m.dev) {
        const d = document.createElement("span");
        d.className = "devtag";
        d.textContent = "dev";
        meta.append(d);
      }
      meta.append(pct, time);
      const text = document.createElement("div");
      text.className = "body";
      text.textContent = m.text;
      el.append(meta, text);
      return el;
    }
    const gate = (title, sub, extra = "") => `<div class="gate"><div class="lock">${ICON.lock}</div><h3>${title}</h3><div class="m sm">${sub}</div>${extra}</div>`;
    const stat = (n) => n == null ? "" : `<div class="stat"><span class="dot"></span><b>${n}</b> ${n === 1 ? "member" : "members"}</div>`;
    return {
      setChatNotice: setNotice,
      addMessages(msgs, reset) {
        const log = root.getElementById("log");
        if (!log) return;
        if (reset) log.textContent = "";
        if (!msgs.length) {
          if (!log.childElementCount) log.innerHTML = `<div class="empty">No messages yet.<br/>Say gm to the family.</div>`;
          return;
        }
        log.querySelector(".empty")?.remove();
        const pinned = log.scrollHeight - log.scrollTop - log.clientHeight < 40;
        for (const m of msgs) log.appendChild(row(m));
        if (pinned || reset) log.scrollTop = log.scrollHeight;
        if (!reset && dock.dataset.min === "true") {
          unread += msgs.filter((m) => m.address !== me).length;
          showUnread();
        }
      },
      render(s) {
        if ("wallet" in s) me = s.wallet.address.toLowerCase();
        dock.dataset.s = s.kind === "holder" ? "live" : s.kind === "error" ? "warn" : "idle";
        const wrongNet = "wallet" in s && !isRobinhood(s.wallet.chainId);
        const net = wrongNet ? `<div class="note">Switch your wallet to ${CHAIN.name} (chain ${CHAIN.id}).</div>` : "";
        switch (s.kind) {
          case "no-token":
            body.innerHTML = `<div class="m">Open a token page on the launchpad to find its community.</div>`;
            break;
          case "no-wallet":
            body.innerHTML = gate("Community chat", "Connect your wallet on the site and we will check if you are in.", stat(s.holders));
            break;
          case "checking":
            body.innerHTML = `<div class="gate"><div class="skel" style="width:60%"></div><div class="skel" style="width:85%"></div><div class="m sm">Checking your balance</div></div>`;
            break;
          case "locked":
            body.innerHTML = gate("Join the community", `Hold this token to unlock the chat and talk with everyone in it.`, stat(s.holders) + net);
            break;
          case "error":
            body.innerHTML = gate("Something went wrong", esc(s.message));
            break;
          case "holder": {
            const bar = `<div class="chip"><i style="background:hsl(${hue(s.wallet.address)} 55% var(--name-l))"></i>${esc(s.wallet.connectorName)} <code>${short(s.wallet.address)}</code></div>
            ${s.isDev ? `<span class="devtag">dev</span>` : ""}<span class="badge">${fmtPct(s.holding.pct)} of supply</span>${s.holders != null ? `<span class="m sm">${s.holders} ${s.holders === 1 ? "member" : "members"}</span>` : ""}${net}`;
            if (root.getElementById("log")) {
              $("bar").innerHTML = bar;
              break;
            }
            body.innerHTML = `<div class="bar" id="bar">${bar}</div><div class="log" id="log"></div>
            <form id="f"><input id="i" maxlength="280" placeholder="Message the family" autocomplete="off"/><button class="send" aria-label="Send">${ICON.send}</button></form>
            <div class="notice" id="n"></div>`;
            const input = $("i");
            $("f").addEventListener("submit", async (e) => {
              e.preventDefault();
              const text = input.value.trim();
              if (!text) return;
              input.value = "";
              try {
                await onSend(text);
                setNotice("");
              } catch (err) {
                input.value = text;
                setNotice(NOTICES[err?.message] ?? "Could not send.");
              }
            });
            break;
          }
        }
      }
    };
  }

  // src/content.ts
  var RECHECK_MS = 3e4;
  var token = tokenFromLocation();
  var current = null;
  var recheck;
  var chatGen = 0;
  var chatFor = "";
  var panel = mountPanel(async (text) => {
    if (!token || !current) throw new Error("no_wallet");
    const msg = await sendMessage(token, current.address, text);
    panel.addMessages([msg]);
    seen = Math.max(seen, msg.id);
  });
  var seen = 0;
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function chatLoop(wallet) {
    const gen = ++chatGen;
    chatFor = wallet.address;
    let after = 0;
    seen = 0;
    while (gen === chatGen && token) {
      try {
        const r = await pollMessages(token, wallet.address, after);
        if (gen !== chatGen) return;
        const fresh = r.messages.filter((m) => m.id > seen);
        if (fresh.length || after === 0) panel.addMessages(fresh, after === 0);
        seen = Math.max(seen, r.last);
        after = r.last;
      } catch (e) {
        if (gen !== chatGen) return;
        if (e?.message === "not_holder") {
          chatFor = "";
          return void evaluate(wallet, false);
        }
        await sleep(3e3);
      }
    }
  }
  function stopChat() {
    chatGen++;
    chatFor = "";
  }
  async function evaluate(wallet, first) {
    if (!token) return;
    if (first) panel.render({ kind: "checking", token, wallet });
    const [info, holders] = await Promise.all([
      checkHolder(token, wallet.address).catch((e) => e),
      holderCount(token).catch(() => void 0)
    ]);
    if (current?.address !== wallet.address) return;
    if (info instanceof Error) return panel.render({ kind: "error", token, wallet, message: "Could not check your balance. Retrying." });
    if (!info.isHolder && !info.isDev) {
      stopChat();
      return panel.render({ kind: "locked", token, wallet, holders });
    }
    panel.render({ kind: "holder", token, wallet, holding: { balance: info.balance, supply: info.supply, pct: info.pct }, isDev: info.isDev, holders });
    if (chatFor !== wallet.address) chatLoop(wallet);
  }
  watchSiteWallet(async (wallet) => {
    current = wallet;
    clearInterval(recheck);
    stopChat();
    if (!token) return panel.render({ kind: "no-token" });
    if (!wallet) {
      panel.render({ kind: "no-wallet", token });
      holderCount(token).then((holders) => !current && panel.render({ kind: "no-wallet", token, holders })).catch(() => {
      });
      return;
    }
    await evaluate(wallet, true);
    recheck = setInterval(() => evaluate(wallet, false), RECHECK_MS);
  });
})();
//# sourceMappingURL=content.js.map
